<?php session_start();
	error_reporting(1);
	include("database.php");
	extract($_POST);
	extract($_GET);
	extract($_SESSION);
	if(isset($subid) && isset($testid))
	{
		$_SESSION[sid]=$subid;
		$_SESSION[tid]=$testid;
		header("location:quiz.php");
	}
	if(!isset($_SESSION[sid]) || !isset($_SESSION[tid]))
	{
		header("location: login.php");
	}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Online Quiz</title>
<link href="quiz.css" rel="stylesheet" type="text/css">
<style>
a
{
	text-decoration:none;
}
a:hover
{
	color:red;
}
</style>

<script type="text/javascript">
function DisplayTime(){
if (!document.all && !document.getElementById)
return
timeElement=document.getElementById? document.getElementById("curTime"): document.all.tick2
var CurrentDate=new Date()
var hours=CurrentDate.getHours()
var minutes=CurrentDate.getMinutes()
var seconds=CurrentDate.getSeconds()
var DayNight="PM"
if (hours<12) DayNight="AM";
if (hours>12) hours=hours-12;
if (hours==0) hours=12;
if (minutes<=9) minutes="0"+minutes;
if (seconds<=9) seconds="0"+seconds;
var currentTime=hours+":"+minutes+":"+seconds+" "+DayNight;
timeElement.innerHTML="<font style='font-family:verdana, arial,tahoma;font-size:12px;color:#E25984; font-weight:bold;'>"+currentTime+"</b>"
setTimeout("DisplayTime()",1000)
}
window.onload=DisplayTime
</script>
<style>
body
{
	padding:0;
	margin:0;	
}
img 
{
	height:80px;
}
alert
{
	position:relative;
    width:300px;
    min-height:100px;
    margin-top:50px;
    border:1px solid #666;
    background-color:#fff;
    background-repeat:no-repeat;
    background-position:20px 30px;
}
</style>
<script language ="javascript" >
        var tim;
       
        var min = 1;
        var sec = 30;
        var f = new Date();
        function f1() {
            f2();
            document.getElementById("starttime").innerHTML = "Your started your Exam at " + f.getHours() + ":" + f.getMinutes();
             
          
        }
        function f2() {
            if (parseInt(sec) > 0) {
                sec = parseInt(sec) - 1;
                document.getElementById("showtime").innerHTML =+ sec+"sec";
                tim = setTimeout("f2()", 1000);
            }
            else {
                if (parseInt(sec) == 0) {
                    min = parseInt(min) - 1;
                    if (parseInt(min) == 0) {
                        clearTimeout(tim);
                        window.location.reload();
                    }
                    else {
                        sec = 60;
                        document.getElementById("showtime").innerHTML =+ sec + "sec";
                        tim = setTimeout("f2()", 1000);
                    }
                }
               
            }
        }
    </script>
</head>
<body style="padding:0;margin:0;" onload="f1()">

<?php
	include("header.php");
	$query="select * from mst_question";
	$rs=("select * from mst_question where test_id=$tid");
	$qry=mysqli_query($cn,$rs);
	if(!isset($_SESSION[qn]))
	{
		$_SESSION[qn]=0;
		$rsl=("delete from mst_useranswer where sess_id='" . session_id() ."'") or die(mysql_error());
		mysqli_query($cn,$rsl);
		$_SESSION[trueans]=0;
	}
	else
	{	
		if($submit=='Next' && isset($ans))
		{
			mysqli_data_seek($qry,$_SESSION[qn]);
			$row= mysqli_fetch_row($qry);	
			$rsl1=("insert into mst_useranswer(sess_id, test_id, que_des, ans1,ans2,ans3,ans4,true_ans,your_ans) values ('".session_id()."', $tid,'$row[2]','$row[3]','$row[4]','$row[5]', '$row[6]','$row[7]','$ans')");
			mysqli_query($cn,$rsl1);
			if($ans==$row[7])
			{
				$_SESSION[trueans]=$_SESSION[trueans]+1;
			}
			$_SESSION[qn]=$_SESSION[qn]+1;
		}
		else if($submit=='Get Result' && isset($ans))
		{
			mysqli_data_seek($qry,$_SESSION[qn]);
			$row= mysqli_fetch_row($qry);	
			$rsl2=("insert into mst_useranswer(sess_id, test_id, que_des, ans1,ans2,ans3,ans4,true_ans,your_ans) values ('".session_id()."', $tid,'$row[2]','$row[3]','$row[4]','$row[5]', '$row[6]','$row[7]','$ans')");
			mysqli_query($cn,$rsl2);
			if($ans==$row[7])
			{
				$_SESSION[trueans]=$_SESSION[trueans]+1;
			}
			echo "<br><center><img src='images/logo.gif'></center><br><br>";
			echo "<h1 class=head1> Result</h1>";
			$_SESSION[qn]=$_SESSION[qn]+1;
			echo "<Table align=center><tr class=tot><td>Total Question<td> $_SESSION[qn]";
			echo "<tr class=tans><td>True Answer<td>".$_SESSION[trueans];
			$w=$_SESSION[qn]-$_SESSION[trueans];
			echo "<tr class=fans><td>Wrong Answer<td> ". $w;
			echo "</table>";
			$date = date_default_timezone_set('Asia/Kolkata');
			$newDateTime=date('h:i:s',time());
			$rsl3=("insert into mst_result(login,test_id,test_date,score,test_time) values('$login',$tid,'".date("y/m/d")."',$_SESSION[trueans],'$newDateTime')");
			mysqli_query($cn,$rsl3);
			echo "<h1 align=center><a href=review.php> Review Question</a></h1><br><br><br><br><br><br><br><br><br><br><br><br><br>";
			unset($_SESSION[qn]);
			unset($_SESSION[sid]);
			unset($_SESSION[tid]);
			unset($_SESSION[trueans]);
			exit;
		}
	}
	$rs=("select * from mst_question where test_id=$tid");
	$qry=mysqli_query($cn,$rs);
	if($_SESSION[qn]>mysqli_num_rows($qry)-1)
	{
		unset($_SESSION[qn]);
		echo "<h1 class=head1>No Questions</h1>";
		echo "<center><a href=sublist.php style='font-size:24px;'>Start Again</a><br><br><br><br><br><br>";
		exit;
	}
	echo "<center>";
	echo "";
	echo "<span id=curTime></span>";
	echo "</center>";
	mysqli_data_seek($qry,$_SESSION[qn]);
	$row= mysqli_fetch_row($qry);
	echo "<form name=myfm method=post action=quiz.php id='form1' runat='server'>";
	echo "<center><img src='images/logo.gif'><br><br></div><div id='endtime'></div>
	<div id='showtime' style='Color:red;font-size:25px;color:white;margin-left:620px;margin-right:620px;padding:5px;background:black;'></div>";
	echo "<table width=100%> <tr> <td width=30>&nbsp;<td> <table border=0>";
	$n=$_SESSION[qn]+1;
	echo "<tr><td><span class=style2 style='font-size:23px;'>Q".  $n .": $row[2]</style>";
	echo "<tr><td class=style8 style='font-size:20px;'>A.<input type=radio name=ans id='option1' value=1 required='required'><label for ='option1'/>$row[3]</label>";
	echo "<tr><td class=style8 style='font-size:20px;'>B.<input type=radio name=ans id='option2' value=2><label for ='option2'/>$row[4]</label>";
	echo "<tr><td class=style8 style='font-size:20px;'>C.<input type=radio name=ans id='option3' value=3><label for ='option3'/>$row[5]</label>";
	echo "<tr><td class=style8 style='font-size:20px;'>D.<input type=radio name=ans id='option4' value=4><label for ='option4'/>$row[6]</label>";
	if($_SESSION[qn]<mysqli_num_rows($qry)-1)
	{	
		echo "<center>";
		echo "<style>.btnsign
		{
			border: 2px solid transparent;
			background:#2196F3;
			color: #ffffff;
			font-size: 16px;
			line-height: 25px;
			padding: 3px 0;
			text-decoration: none;
			text-shadow: none;
			border-radius: 5px;
			box-shadow: none;
			transition: 0.25s;
			width: 120px;
			margin: 0 auto;
		}
		.btnsign:hover
		{
			background-color: #2980B9;
		}
		</style>";
		echo "<center><tr><td><input type=submit name=submit class='btnsign' value='Next'></form><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
	}
	else
	{	
		echo "<style>.btnsign
		{
			border: 2px solid transparent;
			background:#2196F3;
			color: #ffffff;
			font-size: 16px;
			line-height: 25px;
			padding: 3px 0;
			text-decoration: none;
			text-shadow: none;
			border-radius: 5px;
			box-shadow: none;
			transition: 0.25s;
			width: 120px;
			margin: 0 auto;
		}
		.btnsign:hover
		{
			background-color: #2980B9;
		}
		</style>";
		echo "<br><tr><td><input type=submit name=submit class='btnsign' value='Get Result'></form><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
		echo "</table></table>";
	}
?>
</body>
</html>