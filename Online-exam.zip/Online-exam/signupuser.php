<!DOCTYPE HTML">
<html>
<head>
<title>User Signup</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
include("header.php");
extract($_POST);
include("database.php");
$rs="select * from mst_user where email='$email' OR login='$lid'";
$qry=mysqli_query($cn,$rs);
if (mysqli_num_rows($qry)>0)
{
	echo "<script>alert('$lid is already exist in our database, Please try another one!')</script>
	<script>window.open('signup.php','_self')</script>";
	exit;
}
$query="insert into mst_user(login,pass,username,phone,email) values('$lid','$pass','$name','$phone','$email')";
$rs1=mysqli_query($cn,$query);
echo "<script>alert('Your Login ID $lid Created Sucessfully.')</script>
<script>window.open('login.php','_self')</script>";
echo "<style>.btnsign
{
	border: 2px solid transparent;
	background:#0000CD;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 7px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 140px;
	margin: 0 auto;
}
.btnsign:hover
{
	background-color: #2980B9;
}</style>";
echo "<br><div class=head1><a href=login.php><input type='submit' value='Login' class='btnsign'/></a></div>";
?>
</body>
</html>

