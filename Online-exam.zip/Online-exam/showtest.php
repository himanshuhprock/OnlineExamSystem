<?php session_start();
error_reporting(1);
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Online Quiz - Test List</title>
<style>
a
{
	text-decoration:none;
}
a:hover
{
	color:red;
}
body
{
	padding:0;
	margin:0;	
}
img 
{
	height:100px;
}
</style>
</head>
<body style="padding:0;margin:0;">
<?php
include("header.php");
include("database.php");
extract($_GET);
$rs1="select * from mst_subject where sub_id=$subid";
$qry=mysqli_query($cn,$rs1);
$row1=mysqli_fetch_array($qry);
echo"<center><img src='images/logo.gif'>";
echo "<h1 align=center><font color=blue> $row1[1]</font></h1>";
$rs="select * from mst_test where sub_id=$subid";
$qry1=mysqli_query($cn,$rs);
if(mysqli_num_rows($qry1)<1)
{
	echo "<br><br><h2 class=head1> No Quiz for this Subject </h2>";
	exit;
}
echo "<table align=center>";

while($row=mysqli_fetch_row($qry1))
{
	echo "<tr><td align=center ><a href=quiz.php?testid=$row[0]&subid=$subid><font size=4>$row[2]</font></a>";
}
echo "</table><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
?>
</body>
</html>
