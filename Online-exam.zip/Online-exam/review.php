<?php
session_start();
extract($_POST);
extract($_SESSION);
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Online Quiz - Review Quiz </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
<style>
body
{
	padding:0;
	margin:0;	
}
img 
{
	height:80px;
}
</style>
</head>

<body style="margin:0;padding:0;">
<?php
include("header.php");
include("database.php");
echo "<br><center><img src='images/logo.gif'></center><br>";
echo "<h1 class=head1 style='color:Green;'>Test Answer And Result</h1>";
if(!isset($_SESSION[qn]))
{
		$_SESSION[qn]=0;
}
else if($submit=='Next Answer' )
{
	$_SESSION[qn]=$_SESSION[qn]+1;
}
if($submit=='Finish')
{
	$rsl=("delete from mst_useranswer where sess_id='" . session_id() ."'");
	mysqli_query($cn,$rsl);
	unset($_SESSION[qn]);
	header("Location: login.php");
	exit;
}
$rs=("select * from mst_useranswer where sess_id='" . session_id() ."'");
$qry=mysqli_query($cn,$rs);
mysqli_data_seek($qry,$_SESSION[qn]);
$row= mysqli_fetch_row($qry);
echo "<form name=myfm method=post action=review.php>";
echo "<table width=100%> <tr> <td width=30>&nbsp;<td> <table border=0>";
$n=$_SESSION[qn]+1;
echo "<tR><td><span class=style2 style='font-size:23px;'>Q.".  $n .": $row[2]</style>";
echo "<tr><td class=".($row[7]==1?'tans':'style8')." style='font-size:20px;'>A.$row[3]";
echo "<tr><td class=".($row[7]==2?'tans':'style8')." style='font-size:20px;'>B.$row[4]";
echo "<tr><td class=".($row[7]==3?'tans':'style8')." style='font-size:20px;'>C.$row[5]";
echo "<tr><td class=".($row[7]==4?'tans':'style8')." style='font-size:20px;'>D.$row[6]";
if($_SESSION[qn]<mysqli_num_rows($qry)-1)
{
echo "<style>.btnsign
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 3px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 120px;
	margin: 0 auto;
}
.btnsign:hover
{
	background-color: #2980B9;
}</style>";	
echo "<tr><td><input type=submit name=submit class='btnsign' value='Next Answer'></form><br><br><br><br><br><br><br><br><br><br><br><br><br>";
}
else
{	
echo "<style>.btnsign
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 3px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 120px;
	margin: 0 auto;
}
.btnsign:hover
{
	background-color: #2980B9;
}</style>";
echo "<tr><td><input type=submit name=submit class='btnsign' value='Finish'></form><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
echo "</table></table>";
}
?>
