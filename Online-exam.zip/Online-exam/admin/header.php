<style type="text/css">
</style>
<center><h2 style="color:#FFFAF0;background:black;margin:0 0px;padding:10px">ONLINE QUIZ EXAMINATION SYSTEM</h2></center>
  <table width="100%">
  <tr>
    <td aling=right>
	<?php
	if(isset($_SESSION['alogin']))
	{
	 echo "<div align=\"right\"><strong><a href=\"menu.php\" style='text-decoration:none;'>Admin Home</a>|<a href=\"signout.php\" style='text-decoration:none;'>Signout</a></strong></div>";
	 }
	 else
	 {
	 	echo "&nbsp;";
	 }
	?>
	</td>
  </tr>
</table>