<?php session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Administrative Login - Online Exam</title>
<style>
body
{
	padding:0;
	margin:0;	
	background:url(../images/admin.jpg);
	background-size:100% 100%;
	background-attachment:fixed;
}
img 
{
	border-radius:50%;
	height:90px;
	width:90px;
	opacity: 0.6;
	filter: alpha(opacity=40);
}
img:hover
{
	opacity: 1.0;
	filter: alpha(opacity=100);
}
* {
  box-sizing: border-box;
}
.logininput 
{
  display: block;
  padding: 15px 10px;
  margin-bottom: 10px;
  width: 280px;
  border: 1px solid #ddd;
  transition: border-width 0.2s ease;
  border-radius: 2px;
  color: #ccc;
}

.logininput:focus 
{
  outline: none;
  color: #444;
  border-color: #2196F3;
  border-left-width: 35px;
}
.logininput:focus + i.fa 
{
  opacity: 1;
  left: 20px;
  transition: all 0.25s ease-out;
}
.login a 
{
  font-size: 0.8em;
  color: #2196F3;
  text-decoration: none;
}
.btn
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 10px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 280px;
	margin: 0 auto;
}
.btn:hover
{
	background-color: #2980B9;
}
.btnsign
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 7px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 140px;
	margin: 0 auto;
}
.btnsign:hover
{
	background-color: #2980B9;
}
.loginscreen 
{
	margin: 18px auto;
	width: 330px;
	border-radius:10px;
	background:black;
}
.login-screen
 {
	padding: 16px;
	border-radius: 10px;
}
</style>
<script>
function user(id)
{
	var type=(id.which)?id.which:event.KeyCode
	if(type>31 && 14 &&(type<97||type>122))
	{
		return false;
		return true;
	}	
}
</script>
</head>
<body>
<?php
	include("header.php");
?>
<marquee><b style="color:white">Administrative Area: Online Quiz Examination System</b></marquee>
<center><br><br>
	<a href="../index.html"><img src="home.png" title="Home Page"></a>
	<div class="loginscreen">
		<div class="login-screen">
			<h1 style="color:white;">Login</h1>
			<form name="form1" method="post" action="menu.php">
				<input name="loginid" placeholder="username" maxlength="15" onkeypress="return user(event);" autofocus class="logininput" type="text" id="loginid" required oninvalid="setCustomValidity('Please enter username???')" oninput="setCustomValidity('')" />
				<input name="pass" placeholder="password" maxlength="10" class="logininput" type="password" id="pass" required oninvalid="setCustomValidity('Please enter Password???')" oninput="setCustomValidity('')" />
				<input name="submit" type="submit" id="submit" class="btn" value="Login"><br><br>
			</form>
		</div>
	</div>
<footer>
	<b style="color:green;">@developed By:Himanshu Pandey</b>
</footer>	
</body>
</html>
