<?php session_start();
	include("header.php");
	error_reporting(1);
?>
<html>
<head>
<style>
body
{
	padding:0;
	margin:0;	
}
</style>
<style>
	.question
	{
		width:78%;
		height:75px;
		border:navy 2px solid;
		padding:7px;
		font-size:18px;
		border-radius:4px;
	}
	.optionA
	{
		width:78%;
		height:40px;
		border:navy 2px solid;
		padding:7px;
		font-size:18px;
		border-radius:4px;
	}
	.answer
	{
		width:100px;
		height:40px;
		border:navy 2px solid;
		padding:7px;
		font-size:18px;
		border-radius:4px;
	}
	.btn
	{
		border: 2px solid transparent;
		background:#2196F3;
		color: #ffffff;
		font-size: 16px;
		line-height: 25px;
		padding: 4px 0;
		text-decoration: none;
		text-shadow: none;
		border-radius: 3px;
		box-shadow: none;
		transition: 0.25s;
		width: 100px;
		margin: 0 auto;
	}
	.btn:hover
	{
		background-color: #2980B9;
	}
	a:hover
	{
		color:red;
	}
</style>		
<?php
	require('../database.php');
	extract($_POST);
	echo "<BR>";
	if (!isset($_SESSION[alogin]))
	{
		echo "<br><h2><div  class=head1>You are not Logged On Please Login to Access this Page</div></h2>";
		echo "<a href=login.php><h3 align=center>Click Here for Login</h3></a>";
		exit();	
	}
	if($_POST[submit]=='Save' || strlen($_POST['testid'])>0 )	
	{
		extract($_POST);
		$rslt=("insert into mst_question(test_id,que_desc,ans1,ans2,ans3,ans4,true_ans) values ('$testid','$addque','$ans1','$ans2','$ans3','$ans4','$anstrue')");
		mysqli_query($cn,$rslt);
		echo "<p align=center style='color:green;'>Question Added Successfully.</p>";
		unset($_POST);
	}
?>
<style>
.loginscreen 
{
	margin: 18px auto;
	width: 1000px;
}
.login-screen
 {
	height:510px;
	border-radius: 10px;
	border:solid 5px Orange;
}
.inputdata
 {
	text-align: center;
	background-color:white;
	border:2px solid navy;
	border-radius: 3px;
	font-size: 13px;
	font-weight: 200;
	padding: 6px 0;
	width: 250px;
	transition: border .5s;
}
.inputdata:focus 
{
	border: 2px solid #3498DB;	
	box-shadow: none;
}
.labelreg 
{
 display: inline-block; 
 width: 130px;
 text-align: right;
 padding-right: 7px;
 margin-left:250px;
 font-size: 18px;
 color: #666;
 font-weight: bold;
}
.labelreg1 
{
 display: inline-block; 
 width: 130px;
 text-align: right;
 padding-right: 7px;
 margin-left:24px;
 font-size: 18px;
 color: #666;
 font-weight: bold;
}
textarea
{
	vertical-align:middle;
	height:85px;
	resize: none;
	background-color:white;
	border: 2px solid navy;
	border-radius: 3px;
	font-size: 18px;
	font-weight: 200;
	padding: 6px 0;
	width: 770px;
	transition: border .5s;
}
textarea:hover
{
	border: 2px solid #3498DB;	
	box-shadow: none;
}	
.labeltxtarea
{
	vertical-align:middle;
	display: inline-block; 
	width: 130px;
	text-align: right;
	padding-right: 7px;
	margin-left:24px;
	font-size: 18px;
	color: #666;
	font-weight: bold;
}
.labelreg2 
{
 display: inline-block; 
 width: 130px;
 text-align: right;
 padding-right: 7px;
 margin-left:320px;
 font-size: 18px;
 color: #666;
 font-weight: bold;
}
</style>
<script>
function number(evt)
{
	var charcode=(evt.which)?evt.which:event.KeyCode
	if(charcode<49||charcode>52)
	{
		return false;
		return true;
	}	
}
</script>
</head>
<body style="margin:0;padding:0;">
<h2 style="color:green;text-align:center;">Add Test Question</h2>
<div class="loginscreen">
	<div class="login-screen">
		<form name="form1" method="post"><br>
			<label for ="testid" class="labelreg"/>Select Subject</label>
			<select name="testid" id="testid" class="inputdata" required>
			<option value="">Default</option>
			<?php
				$rs=("Select * from mst_test order by test_name");
				$qry=mysqli_query($cn,$rs);
				while($row=mysqli_fetch_array($qry))
				{
					if($row[0]==$testid)
					{
						echo "<option value='$row[0]' selected>$row[2]</option>";
					}
					else
					{
						echo "<option value='$row[0]'>$row[2]</option>";
					}
				}
			?>
			</select>
			<br><br>
			<label for="addque" class="labeltxtarea"/>Question:</label>
			<textarea name="addque" placeholder="Enter Question?" cols="25" rows="5" maxlength="300" id="addque" required oninvalid="setCustomValidity('Please enter Question???')" oninput="setCustomValidity('')"/></textarea>
			<br><br>
			<label for="ans1" class="labelreg1"/>1:</label>
			<input name="ans1" class="optionA" placeholder="Enter Option 1" type="text" id="ans1" size="150" maxlength="150" required oninvalid="setCustomValidity('Please Enter Option A???')" oninput="setCustomValidity('')"/>
			<br><br>
			<label for="ans2" class="labelreg1"/>2:</label>
			<input name="ans2" class="optionA" placeholder="Enter Option 2" type="text" id="ans2" size="150" maxlength="150" required oninvalid="setCustomValidity('Please enter Option B???')" oninput="setCustomValidity('')"/>
			<br><br>
			<label for="ans3" class="labelreg1"/>3:</label>
			<input name="ans3" class="optionA" placeholder="Enter Option 3" type="text" id="ans3" size="150" maxlength="150" required oninvalid="setCustomValidity('Please enter Option C???')" oninput="setCustomValidity('')"/>
			<br><br>
			<label for="ans4" class="labelreg1"/>4:</label>
			<input name="ans4" class="optionA" placeholder="Enter Option 4" type="text" id="ans4" size="150" maxlength="150" required oninvalid="setCustomValidity('Please enter Option D???')" oninput="setCustomValidity('')"/>
			<br><br>
			<label for="anstrue" class="labelreg2"/>Answer:</label>
			<input name="anstrue" onkeypress="return number(event);" class="answer" placeholder="value(1-4)" type="text" id="anstrue" size="50" maxlength="1" required oninvalid="setCustomValidity('Please Answer(1-4)')" oninput="setCustomValidity('')"/>
			<br><br><center>
			<input type="submit" name="submit" value="Add" class="btn"></center>
		</form>
	</div>
</div>
</body>
</html>