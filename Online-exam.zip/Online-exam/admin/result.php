<?php session_start();
require('myclass.php');
	require('header.php');
	error_reporting(0);
?>
<html>
<head>
<title>Untitled Document</title>
<style>
body{
	margin:0;
	padding:0;
}
</style>
</head>
<body>
<?php 
$obj=new database;
$con=$obj->connect();
echo "<style>#customers
		{
			border-collapse: collapse;
			width: 100%;
		}
		#customers td, #customers th 
		{
			border: 2px solid #ddd;
			text-align: center;
			padding: 8px;
		}
		#customers th 
		{
			padding-top: 12px;
			padding-bottom: 12px;
			background-color: #4CAF50;
			color: white;
		}
		a
		{
			text-decoration:none;
			color:blue;
		}
		a:hover
		{
			color:red;
		}
		img 
		{
			height:80px;
		}
		</style>";
		echo "<center><img src='../images/logo.gif'></center>";
		echo "<center><h1 style='color:green'>Candidate Test Information</h1></center>";
echo "<center><table border='3' id='customers'>";
		echo "<tr>
				<th>Candidate name</th> 
				<th>Test Name</th>
				<th>Date</th>
				<th>time</th>
				<th>Total Questions</th>
				<th>Total Answer</th>
			</tr>";
$sql="SELECT r.* , u.* ,t.* FROM mst_result r,mst_user u,mst_test t WHERE r.test_id=t.test_id AND r.login=u.login ORDER BY username ASC";
$result=$obj->get($con,$sql);
while($row = mysqli_fetch_object($result)) 
{
	echo "<tr>
			<td>$row->username</td>
			<td>$row->test_name</td>
			<td>$row->test_date</td>
			<td>$row->test_time</td>
			<td>$row->total_que</td>
			<td>$row->score</td>
		  </tr>" ;
}
echo "</table>";
?>
</body>
</html>