<?php session_start();
	require('header.php');
	error_reporting(0);
	include("userconnect.php");
	if(isset($_POST['submit']))
	{
		$query = $_POST['query'];
?>
<html>
<head>
<title>Searching</title>
<style>
body
{
	padding:0;
	margin:0;	
	border:15px solid black;
}
a
{
	text-decoration:none;
}
a:hover
{
	color:red;
}
img
{
	height:80px;
}
</style>
</head>
<body>
<?php
	$min_length = 1;
	if(strlen($query) >= $min_length)
	{
		$query = htmlspecialchars($query);
		$query = mysqli_real_escape_string($query);
		echo"<center><img src='../images/logo.gif'></center>";
		echo"<center><h2 style='color:Navy;'>Candidate Information</h2></center>";
		echo"<br>";
		echo "<style>#customers
		{
			border-collapse: collapse;
			width: 100%;
		}
		#customers td, #customers th 
		{
			border: 2px solid #ddd;
			text-align: center;
			padding: 8px;
		}
		#customers th 
		{
			padding-top: 12px;
			padding-bottom: 12px;
			background-color: #4CAF50;
			color: white;
		}
		</style>";
		echo "<table border='3' id='customers'>";
		echo "<tr>
				<th>Name</th> 
				<th>Mobile Number</th>
				<th>Email Address</th>
			</tr>";
		$raw_results =("SELECT * FROM mst_user WHERE (`username` LIKE '%".$query."%') OR (`phone` LIKE '%".$query."%') OR (`email` LIKE '%".$query."%')");	
		$qry=mysqli_query($cn,$raw_results);
		if(mysqli_num_rows($qry) > 0)
		{
			while($results = mysqli_fetch_array($qry))
			{
				echo "<tr>
						<td><a href='#'/>".$results['username']."</a></td> 
						<td>".$results['phone']."</td>
						<td>".$results['email']."</td>
					</tr>" ;
			}
		}
		else
		{
			echo "<tr><td colspan='5'>No results found.</td><tr>";
			echo "</table>";
		}
	}
	else
	{
		echo "Minimum length is ".$min_length;
	}
}
?>
</body>
</html> 