<?php require('function.php');
class connectDB
{
	protected $host = 'localhost';
	protected $user = 'root';
	protected $pass = '';
	protected $dbname = 'quiz';
	protected $con;
	function connect()
	{
		$con=new mysqli($this->host,$this->user,$this->pass,$this->dbname);
		return $con;
	}
}
?>