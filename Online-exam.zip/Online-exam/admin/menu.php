<?php session_start();
	error_reporting(1);
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Adminstrative AreaOnline Quiz </title>
<style>
a
{
	text-decoration:none;
}
a:hover
{
	color:red;
}
</style>
<style>
body
{
	padding:0;
	margin:0;	
}
img 
{
	height:80px;
}
.imgadmin
{
	height:100px;
	width:140px;
	border-radius:10px;
}
.aa
{
	color:blue;
}
.aa:hover
{
	color:red;
}
</style>
</head>

<body style="margin:0;padding:0;">
<?php
	include("header.php");
	extract($_POST);
	if(isset($submit))
	{
		include("../database.php");
		$rs=("select * from mst_admin where loginid='$loginid' and pass='$pass'");
		$qry=mysqli_query($cn,$rs);
		if(mysqli_num_rows($qry)<1)
		{
			echo "<BR><BR><BR><BR><center><div class=head1><h1 style='color:red'>Invalid User Name or Password</h1><div>";
			echo "<style>
			.btnsign
			{	
				border: 2px solid transparent;
				background:#2196F3;
				color: #ffffff;
				font-size: 16px;
				line-height: 25px;
				padding:4px 0;
				text-decoration: none;
				text-shadow: none;
				border-radius: 5px;
				box-shadow: none;
				transition: 0.25s;
				width: 100px;
				margin: 0 auto;
			}
			.btnsign:hover
			{
				background-color: #2980B9;
			}
			</style>";
			echo "<center><a href='login.php'/><input type='submit' value='try again' class='btnsign'/></a><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
		exit;
	}
	$_SESSION['alogin']="true";
}
else if(!isset($_SESSION[alogin]))
{
	echo "<BR><BR><BR><BR><div class=head1> Your are not logged in<br> Please <a href=login.php>Login</a><div>";
		exit;
}
?>
<?php
	require('myclass.php');
	$obj=new database;
	$con=$obj->connect();
	$sql="SELECT * from mst_admin_pic";
	$result=$obj->get($con,$sql);
	while($row = mysqli_fetch_object($result)) 
	{
		echo "<center><img src='$row->photo' class='imgadmin' alt='user picture' height='100%' width='100%'/>";
		echo "<center><a href='https://wwww.sites.google.com/site/himanshupandeyhprock' class='aa'>$row->name</a>";
	}	
?>		
<center>
<h1 class="head1" style="color:#2196F3;font-size:30px;">Admin Area</h1></center><br><br>
	<center>
		<a href="subadd.php" style="font-size:24px;"><b>SUBJECT COLLECT</b></a><br><br>
		<a href="testadd.php" style="font-size:24px;"><b>ADD TEST</b></a><br><br>
		<a href="questionadd.php" style="font-size:24px;"><b>ADD QUESTION</b></a><br><br>
		<a href="search.php" style="font-size:24px;"><b>CANDIDATE INFORMATION</b></a><br><br>
		<a href="result.php" style="font-size:24px;"><b>CANDIDATE RESULTS</b></a><br><br><br><br><br><br><br>
		<br>
		</div>
</body>
</html>
