<?php
	$cn=mysqli_connect("localhost","root","","quiz") or die("Could not Connect My Sql");	
?>