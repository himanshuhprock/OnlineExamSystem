<?php
require_once 'db.php';
$html = '<center><tr>';
$html .= '<td class="small">usernameString</td>';
$html .= '<td class="small">phoneString</td>';
$html .= '<td class="small">emailString</td>';
$html .= '</tr>';
$search_string = preg_replace("/[^A-Za-z0-9]/", " ", $_POST['query']);
$search_string = $test_db->real_escape_string($search_string);
if (strlen($search_string) >= 1 && $search_string !== ' ') 
{
	
	$query = 'SELECT * FROM mst_user WHERE username LIKE "%'.$search_string.'%"';
	$result = $test_db->query($query);
	while($results = $result->fetch_array()) 
	{
		$result_array[] = $results;
	}
	if (isset($result_array)) 
	{
		foreach ($result_array as $result) 
		{
		 $d_name = preg_replace("/".$search_string."/i", "<b>".$search_string."</b>", $result['username']);
		 $d_comp = $result['phone'];
		 $d_zip = $result['email'];
		$o = str_replace('usernameString', $d_name, $html);
		$o = str_replace('phoneString', $d_comp, $o);
		$o = str_replace('emailString', $d_zip, $o);
		echo($o);
			}
		}
		else
		{
		$o = str_replace('usernameString', '<span class="label label-danger">No Names Found</span>', $html);
		$o = str_replace('phoneString', '', $o);
		$o = str_replace('emailString', '', $o);
		echo($o);
	}
}
?>