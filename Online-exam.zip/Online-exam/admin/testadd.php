<?php
session_start();
error_reporting(1);
if (!isset($_SESSION['alogin']))
{
	echo "<br><h2>You are not Logged On Please Login to Access this Page</h2>";
	echo "<a href=login.php><h3 align=center>Click Here for Login</h3></a>";
	exit();
}
?>
<?php
require("../database.php");

include("header.php");
if($_POST[submit]=='Save' || strlen($_POST['subid'])>0 )
{
extract($_POST);
$rsl=("insert into mst_test(sub_id,test_name,total_que) values ('$subid','$testname','$totque')");
mysqli_query($cn,$rsl);
echo "<p align=center>Test <b>\"$testname\"</b> Added Successfully.</p>";
unset($_POST);
}
?>
<html>
<head>
<style>
body
{
	padding:0;
	margin:0;	
}
</style>
<style>
.labelreg 
{
 display: inline-block; 
 width: 130px;
 text-align: right;
 padding-right: 7px;
 margin-left:240px;
 font-size: 18px;
 color: #666;
 font-weight: bold;
}
.inputdata
 {
	text-align: center;
	background-color:white;
	border:2px solid navy;
	border-radius: 3px;
	font-size: 13px;
	font-weight: 200;
	padding: 6px 0;
	width: 250px;
	transition: border .5s;
}
.inputdata:focus 
{
	border: 2px solid #3498DB;	
	box-shadow: none;
}
.btn
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 5px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 120px;
	margin: 0 auto;
}
.btn:hover
{
	background-color: #2980B9;
}
.loginscreen 
{
	margin: 18px auto;
	width: 1000px;
}
.login-screen
 {
	height:260px;
	border-radius: 10px;
	border:solid 5px navy;
}
a:hover
{
	color:red;
}
</style>
<script>
function number(evt)
{
	var charcode=(evt.which)?evt.which:event.KeyCode
	if(charcode<48||charcode>52)
	{
		return false;
		return true;
	}	
}
</script>
</head>
<body style="margin:0;padding:0;"><br><br>
<marquee><b style="color:Navy;font-size:30px;">Online Quiz Examination System</b></marquee><br><br>
<h2 style="color:green;text-align:center;">Add Examination Test</h2>
<div class="loginscreen">
	<div class="login-screen">
	<br><br>
<form name="form1" method="post">
	<label for ="testid" class="labelreg"/>Select Subject</label>
	<select id="testid" class="inputdata" required>
	<option value="">Default</option>
	<?php
	$rs=("Select * from mst_subject order by  sub_name");
	  $qry1=mysqli_query($cn,$rs);
	  while($row=mysqli_fetch_array($qry1))
	{
	if($row[0]==$subid)
	{
		echo "<option value='$row[0]' selected>$row[1]</option>";
	}
	else
	{
		echo "<option value='$row[0]'>$row[1]</option>";
	}
	}
	?>
    </select>
	<br><br>
	<label for ="testname" class="labelreg">Test Name</label>
	<input name="testname" placeholder="Enter Exam Name" class="inputdata" type="text" id="testname" required oninvalid="setCustomValidity('Please Enter Exam Name???')" oninput="setCustomValidity('')"/>
    <br><br>
	<label for ="totque" class="labelreg"/>Total Question</label>
	<input name="totque" maxlength="3" onkeypress="return number(event);" placeholder="Enter Total Question" class="inputdata" type="text" id="totque" required oninvalid="setCustomValidity('Please enter total Question???')" oninput="setCustomValidity('')"/>
    <br><br><br>
	<center>
	<input type="submit" name="submit" class="btn" value="Save"></center>
</form>
</div>
</div>
</body>
</html>
