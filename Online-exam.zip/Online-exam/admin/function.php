<?php
class database extends connectDB
{
	function get($con,$sql)
	{
		return $con->query($sql);
	}
}
?>