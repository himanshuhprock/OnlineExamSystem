<?php session_start();
require('header.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="PHP MySQL & Ajax Live Data Table Tutorial">
	<meta name="author" content="LekkerLogic.com">
	<title>Student Information</title>
	<link href="assets/css/bootstrap.css" rel="stylesheet">
	<link href="assets/css/style-responsive.css" rel="stylesheet">
	<link href="assets/css/table-responsive.css" rel="stylesheet">
	<style>
	a
	{
		color:blue;
		font-size:13px;
	}
	a:hover
	{
		color:red;
	}
	</style>
</head>
<body onLoad="document.forms.search.part.focus()">
		<section id="container" >
			<section id="main-content" style="margin-left: 0px;">
				<section class="wrapper">
					<div class="row">
						<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3">
						<p>Type a name to begin searching</p>
								<form class="form-horizontal" name="search" role="form" method="POST" onkeypress="return event.keyCode != 13;">
									<div class="input-group col-sm-11">
										<input id="name" name="name" type="text" class="form-control" placeholder="Search by name..." autocomplete="off"/>
										<span class="input-group-btn">
											<button type="button" class="btn btn-default btnSearch">
												<span class="glyphicon glyphicon-search"> </span>
											</button> </span>	
									</div>
								</form>
						</div>
					</div>
					<div class="row mt">
						<div class="col-lg-12">
							<div class="content-panel tablesearch">
								<section id="unseen">
									<table id="resultTable" class="table table-bordered table-hover table-condensed">
										<thead>
											<tr>
												<th class="small">Candidate Name</th>
												<th class="small">Candidate Mobile Number</th>
												<th class="small">Candidate Email Address</th>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
								</section>
							</div>
						</div>
					</div>
				</section>
			</section>
		</section>
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
		<script type="text/javascript" src="scripts/triggers.js"></script>
	</body>
</html>