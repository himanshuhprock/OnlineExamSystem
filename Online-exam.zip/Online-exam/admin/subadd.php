<?php session_start();
	include("header.php");
	error_reporting(1);
?>
<?php
	require('../database.php');
	extract($_POST);
	echo "<BR>";
	if (!isset($_SESSION['alogin']))
	{
		echo "<br><h2><div  class=head1>You are not Logged On Please Login to Access this Page</div></h2>";
		echo "<a href=login.php><h3 align=center>Click Here for Login</h3></a>";
		exit();
	}
	echo "<table width=100%>";
	echo "<tr><td align=center></table>";
	if($submit=='submit' || strlen($subname)>0 )
	{
		$rs=("select * from mst_subject where sub_name='$subname'");
		$qry=mysqli_query($cn,$rs);
	if (mysqli_num_rows($qry)>0)
	{
		echo "<center>";
		echo "<div class=head1><h2 style='color:red'>Subject is Already Exists</h2></div>";
		echo "<style>
		.btnsign
		{
			border: 2px solid transparent;
			background:#2196F3;
			color: #ffffff;
			font-size: 16px;
			line-height: 25px;
			padding: 7px 0;
			text-decoration: none;
			text-shadow: none;
			border-radius: 5px;
			box-shadow: none;
			transition: 0.25s;
			width: 140px;
			margin: 0 auto;
		}
	.btnsign:hover
	{
		background-color: #2980B9;
	}
	</style>";
	echo "<center><a href='subadd.php'/><input type='submit' value ='try again' class='btnsign'/></a>";
	exit;
}
	$rslt=("insert into mst_subject(sub_name) values ('$subname')");
	mysqli_query($cn,$rslt);
	echo "<p align=center style='color:green;'>Subject  <b> \"$subname \"</b> Added Successfully.</p>";
	$submit="";
}
?>
<html>
<head>
<title>Add Subject</title>
<style>
body
{
	padding:0;
	margin:0;	
}
</style>
<style>
.loginscreen 
{
	margin: 18px auto;
	width: 500px;
}
.login-screen
 {
	height:240px;
	border-radius: 10px;
	border:solid 5px navy;
}
.btnsign
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 5px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 120px;
	margin: 0 auto;
}
.btnsign:hover
{
	background-color: #2980B9;
}
.labelreg 
{
 display: inline-block; 
 width: 130px;
 text-align: right;
 padding-right: 7px;
 margin-left:24px;
 font-size: 18px;
 color: #666;
 font-weight: bold;
}
.inputdata
 {
	text-align: center;
	background-color:white;
	border:2px solid navy;
	border-radius: 3px;
	font-size: 13px;
	font-weight: 200;
	padding: 6px 0;
	width: 250px;
	transition: border .5s;
}
.inputdata:focus 
{
	border: 2px solid #3498DB;	
	box-shadow: none;
}
a:hover
{
	color:red;
}
</style>
</head>
<body style="margin:0;padding:0;"/>
<marquee><b style="color:Navy;font-size:30px;">Online Quiz Examination System</b></marquee><br><br>
<br><br>
<div class="loginscreen">
	<div class="login-screen">
		<center><h1>Subject Collect</h1></center><br>
			<form name="form1" method="post">  
				<label for="subname" class="labelreg"/>Subject Name:</label>
				<input name="subname" class="inputdata" placeholder="enter language name" type="text" id="subname" required oninvalid="setCustomValidity('Please enter Subject??')" oninput="setCustomValidity('')" />
				<br><br><br><center>
				<input type="submit" class="btnsign" name="submit" value="Add"></center>
			</form>
		</div>
	</div>
</body>
</html>