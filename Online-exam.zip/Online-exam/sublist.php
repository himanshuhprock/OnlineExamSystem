<?php
session_start();
error_reporting(1);
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Online Quiz - Quiz List</title>
<style>
a
{
	text-decoration:none;
}
a:hover
{
	color:red;
}
body
{
	padding:0;
	margin:0;	
}
img 
{
	height:100px;
}
</style>
</head>
<body style="margin:0;padding:0;">
<?php
include("header.php");
include("database.php");
echo "<center>";
echo"<img src='images/logo.gif'>";
echo "<h2 class=head1 style='color:green;'> Select Subject to Give Quiz </h2>";
$rs="select * from mst_subject";
$qry=mysqli_query($cn,$rs);
echo "<table align=center>";
while($row=mysqli_fetch_row($qry))
{
	echo "<tr><td align=center><br><a href=showtest.php?subid=$row[0]><font size=4>$row[1]</font></a></b>";
}
echo "</table><br><br><br><br><br>";
?>
</body>
</html>
