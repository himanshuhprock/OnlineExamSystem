<!DOCTYPE HTML>
<html>
<head>
<title>New user signup </title>
<style>
body
{
	padding:0;
	margin:0;
	background:url(img/intro-bg.jpg);
	background-size:100% 100%;
	background-attachment:fixed;
}
* {
  box-sizing: border-box;
}
.logininput 
{
  display: block;
  padding: 12px 10px;
  margin-bottom: 10px;
  width: 250px;
  border: 1px solid #ddd;
  transition: border-width 0.2s ease;
  border-radius: 2px;
  color: #ccc;
}

.logininput:focus 
{
  outline: none;
  color: #444;
  border-color: #2196F3;
  border-left-width: 35px;
}
.logininput:focus + i.fa {
  opacity: 1;
  left: 20px;
  transition: all 0.25s ease-out;
}
.login a 
{
  font-size: 0.8em;
  color: #2196F3;
  text-decoration: none;
}
.btn
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 18px;
	line-height:15px;
	padding:12px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius:2px;
	box-shadow: none;
	transition: 0.25s;
	width: 250px;
	margin: 0 auto;
}
.btn:hover
{
	background-color: #2980B9;
}
.btnsign
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 7px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 100px;
	margin: 0 auto;
}
.btnsign:hover
{
	background-color: #2980B9;
}
.loginscreen 
{
	margin: 18px auto;
	width: 305px;
	border-radius: 10px;
	border:solid 5px white;
}
.login-screen
 {
	padding:2px;
	border-radius: 10px;
}
img 
{
	border-radius:50%;
	height:70px;
	width:70px;
	opacity: 0.6;
	filter: alpha(opacity=40);
}
img:hover
{
	opacity: 1.0;
	filter: alpha(opacity=100);
}
</style>
<script type="text/javascript">
window.onload = function ()
 {
	document.getElementById("pass").onchange = validatePassword;
	document.getElementById("cpass").onchange = validatePassword;
}
function validatePassword()
{
	var pass2=document.getElementById("cpass").value;
	var pass1=document.getElementById("pass").value;
	if(pass1!=pass2)
	{
		document.getElementById("cpass").setCustomValidity("password not match");
	}
	else
	{
		document.getElementById("cpass").setCustomValidity('');	 
	}
}
</script>
<script>
function number(evt)
{
	var charcode=(evt.which)?evt.which:event.KeyCode
	if(charcode>31 &&(charcode<48||charcode>57))
	{
		return false;
		return true;
	}	
}
function user(evtt)
{
	var charcode=(evtt.which)?evtt.which:event.KeyCode
	if(charcode>31 && 14 &&(charcode<97||charcode>127))
	{
		return false;
		return true;
	}	
}
function chkpswd()
{
				var x=document.getElementById("pass");
				var y=document.getElementById("cpass");
				if(x.type=='password' && y.type=='password'){
					x.type='text';
					y.type='text';
				}
				else{
					x.type='password';
					y.type='password';
				}
			}
</script>
</head>
<body>
<?php
include("header.php");
?>
<center>
	<a href="index.html"/><img src="home.png" title="Home Page"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="login.php"/><img src="login.png" title="Login"></a>
	<div class="loginscreen">
	<div class="login-screen">
<form name="form1" method="post" action="signupuser.php">
	<h2 style="color:White;">Registration</h2>
    <input type="text" name="lid" autofocus class="logininput" onkeypress="return user(event);" title="Username" maxlength="15" placeholder="username" required oninvalid="setCustomValidity('Please enter Username???')" oninput="setCustomValidity('')"/>
    <input type="password" maxlength="10" name="pass" title="Create Password" class="logininput" placeholder="create password" id="pass" required oninvalid="setCustomValidity('Please Create Password???')" oninput="setCustomValidity('')"/>
    <input name="cpass" type="password" maxlength="10" title="Create conform password" class="logininput" placeholder="Retype Password" id="cpass">
	<input name="name" type="text" class="logininput" title="Your Name" placeholder="Enter your name" id="name" required oninvalid="setCustomValidity('Please enter Your Name???')" oninput="setCustomValidity('')"/>
    <input name="phone" type="text" pattern="[0-9]*" title="Your Mobile Number" onkeypress="return number(event);" maxlength="10" class="logininput" placeholder="Mobile Number" id="phone" required oninvalid="setCustomValidity('Please enter Mobile Number???')" oninput="setCustomValidity('')"/>
    <input name="email" type="email" title="Your Email Address" class="logininput" placeholder="Enter Your Email Address" id="email" required oninvalid="setCustomValidity('Please Enter Email_ID???')" oninput="setCustomValidity('')"/>
    <input type="checkbox" onclick="chkpswd();" id="idchk" name="chkshow"><label for="idchk" style="color:white">Show Password</label><br><br>
	<input type="submit" name="Submit" class="btn" value="SignUp"> <br><br>
</form>
</div></div>
</body>
</html>
