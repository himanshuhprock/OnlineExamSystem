<?php
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Online Quiz  - Result </title>
<style>
body
{
	padding:0;
	margin:0;	
	border:12px solid black;
}
img
{
	height:80px;
}
</style>
</head>
<body style="margin:0;padding:0;">
<?php
include("header.php");
include("database.php");
extract($_SESSION);
$rs=("select t.test_name,t.total_que,r.test_date,r.score,r.test_time from mst_test t, mst_result r where
t.test_id=r.test_id and r.login='$login' ORDER BY r.test_date DESC");
$qry=mysqli_query($cn,$rs);
echo"<center><img src='images/logo.gif'></center>";
echo "<center><h1 class=head1 style='color:green'> Result </h1>";
if(mysqli_num_rows($qry)<1)
{
	echo "<br><br><h1 class=head1> You have not given any quiz</h1>";
	exit;
}
echo "<style>
#customers{
    font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;}
#customers td, #customers th {
    border: 2px solid #ddd;
    text-align: center;
    padding: 8px;}
#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    background-color: #4CAF50;
    color: white;}
	.btn
	{
		border: 2px solid transparent;
		background:#0000CD;
		color: #ffffff;
		font-size: 16px;
		line-height: 25px;
		padding: 5px 0;
		text-decoration: none;
		text-shadow: none;
		border-radius: 5px;
		box-shadow: none;
		transition: 0.25s;
		width: 150px;
		margin: 0 auto;
	}
.btn:hover
{
	background-color: #2980B9;
}
a
{
	text-decoration:none;
}
a:hover
{
	color:red;
}
</style>";
echo "<table border='3' id='customers'>
		<tr>
			<th width=300>Test Name</th>
			<th>Date</th>
			<th>Time</th>
			<th> Total Question</th> 
			<th>Result</th>
		</tr>";	
while($row=mysqli_fetch_row($qry))
{
echo "<tr>
			<td>$row[0]</td>
			<td align=center> $row[2]</td>
			<td align=center> $row[4]</td>
			<td align=center> $row[1]</td>
			<td align=center> $row[3]</td></tr>";
}
echo "</table>";
?>
</body>
</html>
