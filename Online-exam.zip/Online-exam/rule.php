<html>
<head>
</head>
<style>
body
{
	margin:0;
	padding:0;
}
.btnsign
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 7px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 140px;
	margin: 0 auto;
}
.btnsign:hover
{
	background-color: #2980B9;
}
a{
	text-decoration:none;
	color:blue;
}
a:hover
{
	color:red;
}
ul
{
	margin-left:150px;
	margin-right:120px;
	font-size:20px;
}
p
{
	color:Navy;
	font-size:20px;
}
img
{
	height:80px;
}
</style>
<body>
<?php session_start();
include('subjects/header.php');
?>
<center><img src='images/logo.gif'></center>
<center><h2 style="color:green;"/>Examination Rule</h2></center>
<ul>
  <li><p>In This Quiz you will get a number of subjects,from these subjects you can choose any one subject. </p></li>
  <li><p>The subject you have chosen will also have parts,you can choose the subject in which you are interested and can give your exam.</p></li>
  <li><p>You will be provided 20 Questions.</p></li>
  <li><p style="color:red">While giving the exam there will be no back option.</p></li>
  <li><p style="color:red">It is compulsory to do all 20 Questions.</p></li>
  <li><p style="color:red">The Time Duration for each question will be 30 seconds.</p></li>
  <li><p style="color:red">After completing 30 seconds you will not be able to do the question that was appearing on the screen and next question will appear.</p></li>
  <li><p>Each Question will be of 1 marks.</p></li>
  <li><p>After Completing the quiz you can re-check your questions from review option.It will show only right answers.</p></li>
  <li><p>You can give each exam many times.</p></li>
  <li><p>We can view record of exams we have given.</p></li>
</ul>
</body>
</html>