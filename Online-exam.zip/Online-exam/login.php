<?php session_start();
?>
<html>
<head>
<title>Online Exam Login</title>
<style>

body
{
	background:url(img/intro-bg.jpg);
	background-size:100% 100%;
	background-attachment:fixed;
}
.logininput {
  display: block;
  padding: 12px 10px;
  margin-bottom: 10px;
  width:250px;
  border: 1px solid #ddd;
  transition: border-width 0.2s ease;
  border-radius: 2px;
  color: #ccc;
}
.logininput + i.fa {
  color: #fff;
  font-size: 1em;
  position: absolute;
  margin-top: -47px;
  opacity: 0;
  left: 0;
  transition: all 0.1s ease-in;
}
.logininput:focus {
  outline: none;
  color: #444;
  border-color: #2196F3;
  border-left-width: 35px;
}
.logininput:focus + i.fa {
  opacity: 1;
  left: 30px;
  transition: all 0.25s ease-out;
}
.login a 
{
  font-size: 0.8em;
  color: #2196F3;
  text-decoration: none;
}
* {
  box-sizing: border-box;
}
.btn
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 18px;
	line-height: 20px;
	padding: 10px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 250px;
	margin: 0 auto;
}
.btn:hover
{
	background-color: #2980B9;
}
.btnsign
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 7px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 140px;
	margin: 0 auto;
}
.btnsign:hover
{
	background-color: #2980B9;
}
.loginscreen 
{
	margin: 8px auto;
	width: 305px;
	border-radius:10px;
	border:solid 5px white;
}
.login-screen
 {
	padding:3px;
	border-radius: 10px;
}
footer {
            width: 100%;
            bottom: 0;
			font-size:20px;
			color:white;
            position: relative;
        }
		a
		{
			text-decoration:none;
			color:white;
		}
		a:hover
		{
			color:red;
		}
		img 
		{
			border-radius:50%;
			height:70px;
			width:70px;
			opacity: 0.6;
			filter: alpha(opacity=40);
		}
		img:hover
		{
			opacity: 1.0;
			filter: alpha(opacity=100);
		}
</style>
<script>
function user(evtt)
{
	var charcode=(evtt.which)?evtt.which:event.KeyCode
	if(charcode>31 && 14 &&(charcode<97||charcode>127))
	{
		return false;
		return true;
	}	
}
function chkpswd()
{
				var x=document.getElementById("pass");
				if(x.type=='password'){
					x.type='text';
				}
				else{
					x.type='password';
				}
			}
</script>
</head>

<body style="margin:0;padding:0;">

<?php
	include("header.php");
	include("database.php");
	extract($_POST);
	if(isset($submit))
	{
		$rs="select * from mst_user where login='$loginid' and pass='$pass'";
		$query=mysqli_query($cn,$rs);
		if(mysqli_num_rows($query)<1)
		{
			$found="N";
		}
		else
		{
			$_SESSION[login]=$loginid;
		}
	}
	if(isset($_SESSION[login]))
	{
		echo "<h1 class='style8' align=center style='color:white'>Welcome $_SESSION[login]</h1>";
		echo "<marquee><b style='color:white'>Online Quiz Examination System</b></marquee>";
		echo '<table width="28%"  border="0" align="center">
		<tr>
			<td width="93%" valign="bottom" bordercolor="#0000FF"> <a href="sublist.php"><h1 style="color:Pink;margin-left:60px;">Subject for Quiz</h1></a></td>
		</tr>
		<tr>
			<td valign="bottom"> <a href="result.php"><h1 style="color:Pink;margin-left:125px;">Result</h1> </a></td>
		</tr>
		<tr>
			<td valign="bottom"> <a href="rule.php"><h1 style="color:Pink;margin-left:60px;">Examination Rule</h1> </a></td>
		</tr>
		</table>';
		exit;
	}
	
?>
<marquee><b style="color:white">Online Quiz Examination System</b></marquee>
<center><h1 style="color:white">Candidate Login</h1>
	<a href="index.html"/><img src="home.png" title="Home Page"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="signup.php"/><img src="admin/icon/useradd.png" title="User Create"></a>
	<div class="loginscreen">
	<div class="login-screen">
    <form name="form1" method="post" action="">
		<h1 style="color:white;">Login</h1>
		<b style="color:red;"><?php if(isset($found)) { echo "Invalid Login!!!";}?></b>
        <input name="loginid" autofocus placeholder="username" onkeypress="return user(event);" title="username" maxlength="15" class="logininput" type="text" id="loginid2" required oninvalid="setCustomValidity('Please enter Username??')" oninput="setCustomValidity('')" />
        <input name="pass" class="logininput" maxlength="10" title="Password" placeholder="password" type="password" id="pass" required oninvalid="setCustomValidity('Please enter Password??')" oninput="setCustomValidity('')" />
		<input type="checkbox" onclick="chkpswd();" id="idchk" name="chkshow"><label for="idchk" style="color:white">Show Password</label><br><br>
		<input name="submit" type="submit" id="submit" class="btn" value="Login">  <br>
	</form>
	</div></div><br><br><br><br>
	<footer style="background:black;margin:0 0px;padding:8px">&copy;<a href="http://www.himanshupandey.com" title="Software Developer">Himanshu Pandey</a></footer>
</body>
</html>
