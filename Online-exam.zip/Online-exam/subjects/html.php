<html>
<head>
</head>
<style>
body
{
	margin:0;
	padding:0;
}
.btnsign
{
	border: 2px solid transparent;
	background:#2196F3;
	color: #ffffff;
	font-size: 16px;
	line-height: 25px;
	padding: 7px 0;
	text-decoration: none;
	text-shadow: none;
	border-radius: 5px;
	box-shadow: none;
	transition: 0.25s;
	width: 140px;
	margin: 0 auto;
}
.btnsign:hover
{
	background-color: #2980B9;
}
</style>
<body>
<?php 
include('header.php');
?>
<center><a href="../index.html"/><input type="submit" value="Home" class="btnsign"/></a>
<h1 style="color:green;"/>HTML</h1>
<center><embed src="subject/Html.pdf" width="1200" height="1000"></embed></center>
</body>
</html>